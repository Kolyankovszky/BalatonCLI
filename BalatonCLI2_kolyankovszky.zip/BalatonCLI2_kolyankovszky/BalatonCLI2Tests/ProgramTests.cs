﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BalatonCLI2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BalatonCLI2.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void AdoTest()
        {
            Assert.AreEqual(18000,Program.Ado("C",180));
        }
        [TestMethod()]
        public void AdoTest2()
        {
            Assert.AreEqual(80000, Program.Ado("A", 100));
        }
        [TestMethod()]
        public void AdoTest3()
        {
            Assert.AreEqual(60000, Program.Ado("C", 100));
        }
        [TestMethod()]
        public void AdoTest4()
        {
            Assert.AreEqual(0, Program.Ado("C", 180));
        }
        [TestMethod()]
        public void AdoTest5()
        {
            Assert.AreEqual(0, Program.Ado("C", 90));
        }
    }
}