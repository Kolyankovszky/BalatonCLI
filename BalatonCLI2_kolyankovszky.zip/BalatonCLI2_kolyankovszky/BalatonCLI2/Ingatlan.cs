﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BalatonCLI2
{
    public class Ingatlan
    {
        public string AdoSzam { get; set; }
        public string UtcaNev { get; set; }
        public string HazSzam { get; set; }
        public string AdoKategoria { get; set; }
        public int HazTerulet { get; set; }

        public Ingatlan(string sor)
        {
            string[] darabok = sor.Split(' ');
            AdoSzam = darabok[0];
            UtcaNev = darabok[1];
            HazSzam = darabok[2];
            AdoKategoria = darabok[3];
            HazTerulet = Convert.ToInt32(darabok[4]);
        }
    }
}
