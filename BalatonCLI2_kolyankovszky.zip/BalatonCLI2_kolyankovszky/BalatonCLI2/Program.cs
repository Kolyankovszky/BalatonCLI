﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BalatonCLI2
{
    public class Program
    {
        public static List<Ingatlan>ingatlanLista=new List<Ingatlan>();
        public static int A;
        public static int B;
        public static int C;

        public static int savA = 0;
        public static int savB = 0;
        public static int savC = 0;

        public static int sumTeruletA = 0;
        public static int sumTeruletB = 0;
        public static int sumTeruletC = 0;
        static void Main(string[] args)
        {
            StreamReader sr=new StreamReader("utca.txt");
            string[] AdoOsszeg = sr.ReadLine().Split(' ');
            A = int.Parse(AdoOsszeg[0]);
            B = int.Parse(AdoOsszeg[1]);
            C = int.Parse(AdoOsszeg[2]);
            while (!sr.EndOfStream)
            {
                ingatlanLista.Add(new Ingatlan(sr.ReadLine()));
            }
            sr.Close();
            int ingatlanokSzama = ingatlanLista.Count();
            Console.WriteLine("2. feladat.\n"+"\tA listában "+ingatlanokSzama+" telek szerepel.\n");
            Console.Write("3. feladat\n\tKérem az adószámát: ");
            
            string beAdoSzam = Console.ReadLine();
            
            bool találat = false;
            foreach (var item in ingatlanLista)
            {
                if (item.AdoSzam == beAdoSzam)
                {
                    találat = true;
                    Console.WriteLine(item.UtcaNev+" "+item.HazSzam);
                }
            }
            if (!találat)
            {
                Console.WriteLine("\tNem szerepel.\n");
            }
            
            foreach (var item in ingatlanLista)
            {
                if (item.AdoKategoria == "A")
                {
                    savA++;
                    sumTeruletA += Ado(item.AdoKategoria,item.HazTerulet);
                }
                else if (item.AdoKategoria == "B") { savB++; sumTeruletB += Ado(item.AdoKategoria, item.HazTerulet); }
                else if (item.AdoKategoria == "C") { savC++; sumTeruletC += Ado(item.AdoKategoria, item.HazTerulet); }
            }

            Console.WriteLine("5. feladat:");
            Console.WriteLine("\tA sávban "+savA+" telek esik, az adó "+sumTeruletA+" Ft."+"\n"+ "\tB sávban " + savB + " telek esik, az adó " + sumTeruletB + " Ft." + "\n" + "\tC sávban " + savC + " telek esik, az adó " + sumTeruletC + " Ft.\n");

            StreamWriter sw = new StreamWriter("teljes.txt");
            foreach (Ingatlan ingatlan in ingatlanLista)
            {
                string line = ingatlan.AdoSzam + " " + ingatlan.UtcaNev + " " + ingatlan.HazSzam + " " + ingatlan.AdoKategoria + " " + ingatlan.HazTerulet + " " + Ado(ingatlan.AdoKategoria, ingatlan.HazTerulet);
                sw.WriteLine(line);
                Console.WriteLine(line);
            }
            
            sw.Close();
            
            Console.ReadLine();
        }
        public static int Ado(string Kategoria, int Terulet)
        {
            int Osszeg = 0;
            switch (Kategoria)
            {
                case "A": Osszeg = Terulet * A;break;
                case "B": Osszeg = Terulet * B;break;
                case "C": Osszeg = Terulet * C;break;
            }
            if (Osszeg<10000)
            {
                Osszeg = 0;
            }
            return Osszeg;
        }
    }
}
